import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
import torchvision

use_gpu = torch.cuda.is_available()
def indices(a, func):
    return [i for (i,val) in enumerate(a) if func(val)]

def flip_rates(model, trImages, output_dim, batch_size=1,alpha=0.05,trLabels=None):
    nTr = len(trImages)
    nIters = int(nTr/batch_size)
    probs = torch.zeros(nTr, output_dim)
    cnt = 0
    for iters in range(nIters):
        inputs = trImages[iters*batch_size:(iters+1)*batch_size];
        inputs = torch.from_numpy(inputs).type(torch.FloatTensor)

        if use_gpu:
            inputs = Variable(inputs.cuda())
        else:
            inputs = Variable(inputs)

        output = model(inputs)
        prob = F.softmax(output)
        nums = len(inputs)
        probs[cnt:cnt+nums] = prob.cpu().data
        cnt = cnt + nums

    probs = probs.numpy()
    nSam = int(len(probs)*alpha)
    Q = np.zeros((output_dim,output_dim))

    if not trLabels==None:
        for cls in range(output_dim):
            inds = indices(trLabels, lambda x:x==cls)
            tmpprob = probs[inds]
            Q[cls] = tmpprob.sum(0)/(1.0*len(inds))
    else:
        for cls in range(output_dim):
            temp = probs[:,cls]
            inds = np.argsort(temp)[::-1]
            temp = np.sort(temp)[::-1]
            # print(temp, inds)
            tmpprob = probs[inds[0:nSam]]
            Q[cls] = tmpprob.sum(0)/(1.0*nSam)

    return Q
