import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
import torchvision


use_gpu = torch.cuda.is_available()
def train(model, trImages, trLabels, criterion, optimizer, batch_size=100, total_iters=0, lr_scheduler=None):
    nTrain = 0
    avg_loss = 0.0

    nIters = int(len(trLabels)/batch_size)
    for iters in range(nIters):
        total_iters += 1
        if not lr_scheduler==None:
            optimizer = lr_scheduler(optimizer)

        inputs = trImages[iters*batch_size:(iters+1)*batch_size]
        labels = trLabels[iters*batch_size:(iters+1)*batch_size]
        nTrain += len(labels)

        inputs = torch.from_numpy(inputs).type(torch.FloatTensor)
        labels = torch.from_numpy(labels).type(torch.LongTensor)
        labels = torch.squeeze(labels)
 
        if use_gpu:
            inputs, labels = Variable(inputs.cuda()), Variable(labels.cuda())
        else:
            inputs, labels = Variable(inputs), Variable(labels)

        optimizer.zero_grad()
        output = model(inputs)
        # print(output)
        loss = criterion(output, labels)
        loss.backward()
        optimizer.step()
        avg_loss += loss.data[0]

    avg_loss /= (nTrain*1.0+1e-6)
    
    return model, avg_loss, total_iters            
