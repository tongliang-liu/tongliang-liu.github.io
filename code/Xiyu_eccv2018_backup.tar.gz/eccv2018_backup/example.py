from common_loss import *
import torch
from torch.autograd import Variable

batch_size = 2
nb_digits = 3
target = torch.LongTensor(batch_size, 1).random_() % nb_digits
target = torch.squeeze(target)
target = Variable(target).cuda()
# target = target.cuda()
x = Variable(torch.randn((batch_size, nb_digits))).cuda()
# x = torch.randn((batch_size, nb_digits)).cuda()
iters = -1
for i in target:
    iters += 1
    for j in x[iters]:
        print(i,j)

# print(x.size()[0], x.size()[1])
criterion = ComplementaryPC2Loss(hinge_loss)
loss0 = criterion(x, target)
loss1 = complementary_pc_loss(x, target, hinge_loss)
#criterion = OVALoss(zero_one_loss)
#loss1 = criterion(x, target)
print(loss0, loss1)
