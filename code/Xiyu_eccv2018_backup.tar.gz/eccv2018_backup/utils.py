import numpy as np

def randshuffle(data, labels):
    n = len(labels)
    arr = np.arange(n)
    np.random.shuffle(arr)
    data, labels = data[arr], labels[arr]
 
    return data, labels
