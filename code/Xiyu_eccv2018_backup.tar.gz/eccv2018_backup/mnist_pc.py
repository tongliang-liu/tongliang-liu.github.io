import scipy.io as sio
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
import torchvision
import copy
import math

from train import *
from evaluation import *
from common_loss import *
from classification_models import *
from utils import *

use_gpu = torch.cuda.is_available()

#data = sio.loadmat('dataset/mnist/ten_cls/complementary_data.mat')
#data = sio.loadmat('dataset/mnist/ten_cls/data.mat')
foldername = 'with0'
data = sio.loadmat('dataset/mnist/'+foldername+'/mnist_complementary_data_manualwith0.mat')
trImages = data['trImages']
trLabels = data['trLabels']
valImages = data['valImages']
valLabels = data['valLabels']
tsImages = data['tsImages']
tsLabels = data['tsLabels']
ncls = 10

Q = data['Q']
print(Q)
#qdata = sio.loadmat('dataset/mnist/estimated_q.mat')
#Q = qdata['Q']
#rho = 1.0
#Q = (rho/(ncls-1))*np.ones((ncls,ncls))
#for i in range(ncls):
#    Q[i,i] = 1.0 - rho

Q = torch.from_numpy(Q).type(torch.FloatTensor).cuda()
Q = Variable(Q)
trBatch = 128

#model_ft = LinearModel(784,ncls)
#model_ft = FCNet(784,ncls)
model_ft = LeNet()
model = copy.deepcopy(model_ft)
if use_gpu:
    model_ft = model_ft.cuda()
    model = model.cuda()

#criterion_tr = PCLoss(sigmoid_loss)
#criterion_val = PCLoss(zero_one_loss)
#criterion_tr = ComplementaryOVALoss(sigmoid_loss)
#criterion_val = ComplementaryOVALoss(zero_one_loss)
criterion_tr = ComplementaryPCLoss(sigmoid_loss)
criterion_val = ComplementaryPCLoss(zero_one_loss)
#criterion_tr = ForwardLoss(Q)
#criterion_val = ForwardLoss(Q)

# first step: validation for learning rate and weight decay
maxiters = 60000
best_lr = -1.0
best_weight_decay = -1.0
best_model = copy.deepcopy(model_ft)

lrs = [1e-5,1e-4]
decays = [1e-5,1e-4]

#lrs = [1e-4,1e-3,1e-2,1e-1,1]
#decays = [1e-4,1e-3,1e-2,1e-1,1,1e2,1e3,1e4]
best_val_loss = 1e10
best_val_acc = -1e10
for learning_rate in lrs:
    for decay in decays:
        model_ft = copy.deepcopy(model)
        print("Start training: learning rate {:.4f} and weight decay {:.4f}".format(learning_rate, decay))
        optimizer_ft = optim.Adam(model_ft.parameters(), lr=learning_rate, weight_decay=decay)
        total_iters = 0
        while total_iters < maxiters:
            trImages, trLabels = randshuffle(trImages, trLabels)
            model_ft, train_avg_loss, total_iters = train(model_ft, trImages, trLabels, criterion_tr, optimizer_ft, 128, total_iters)
            val_avg_loss, val_avg_acc = evaluation(model_ft, tsImages, tsLabels, criterion_val, 1)
            print('Training Iter: {:d} Training Loss: {:.4f} Validation Loss: {:.4f} Validation Acc: {:.4f}'.format(total_iters,train_avg_loss, val_avg_loss, val_avg_acc))

            if math.isnan(train_avg_loss):
                break
            if (val_avg_acc > best_val_acc) and (not math.isnan(train_avg_loss)):
                best_val_acc = val_avg_acc
                best_lr = learning_rate
                best_weight_decay = decay
                best_model = copy.deepcopy(model_ft)

print('Best learning rate: {:2.4f} Best weight decay: {:2.4f}'.format(best_lr, best_weight_decay))
test_avg_loss, test_acc = evaluation(best_model, tsImages, tsLabels, criterion_val, 1)
print('Test Loss: {:.4f} Acc: {:.4f}'.format(test_avg_loss, test_acc))
