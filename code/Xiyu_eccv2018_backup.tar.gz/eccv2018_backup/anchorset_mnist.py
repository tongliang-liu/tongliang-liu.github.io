import scipy.io as sio
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
import torchvision
import copy
import math

from train import *
from evaluation import *
from common_loss import *
from classification_models import *
from utils import *

use_gpu = torch.cuda.is_available()

data = sio.loadmat('dataset/mnist/mnist_normal_data.mat')
trImages = data['trImages']
trLabels = data['trLabels']
valImages = data['valImages']
valLabels = data['valLabels']
tsImages = data['tsImages']
tsLabels = data['tsLabels']
ncls = 10
rho = 1.0
Q = np.eye(ncls,ncls)
Q = torch.from_numpy(Q).type(torch.FloatTensor).cuda()
Q = Variable(Q)
trBatch = 128

# model_ft = LinearModel(784,ncls)
model_ft = LeNet()
if use_gpu:
    model_ft = model_ft.cuda()

criterion_tr = ForwardLoss(Q)
criterion_val = ForwardLoss(Q)

# first step: validation for learning rate and weight decay
maxiters = 12800
lrs = 1e-2
decays = 1e-5
optimizer_ft = optim.SGD(model_ft.parameters(), lr=lrs, weight_decay=decays)
total_iters = 0
best_model = copy.deepcopy(model_ft)
best_test_acc = -1e10
while total_iters < maxiters:
    trImages, trLabels = randshuffle(trImages, trLabels)
    model_ft, train_avg_loss, total_iters = train(model_ft, trImages, trLabels, criterion_tr, optimizer_ft, trBatch, total_iters)
    val_avg_loss, val_avg_acc = evaluation(model_ft, valImages, valLabels, criterion_val, 1)
    print('The {:d}-th iteration: Training loss={:.4f} and validation acc={:.4f}'.format(total_iters, train_avg_loss, val_avg_acc))
    if math.isnan(train_avg_loss):
        break
    if (val_avg_acc > best_test_acc) and (not math.isnan(train_avg_loss)):
        best_test_acc = val_avg_acc
        best_model = copy.deepcopy(model_ft)
        
# find anchor set
batch_size = 1
nTr = len(trImages)
nIters = int(nTr/batch_size)
probs = torch.zeros(nTr, ncls)
cnt = 0
for iters in range(nIters):
    inputs = trImages[iters*batch_size:(iters+1)*batch_size];
    inputs = torch.from_numpy(inputs).type(torch.FloatTensor)
    if use_gpu:
        inputs = Variable(inputs.cuda())
    else:
        inputs = Variable(inputs)

    output = best_model(inputs)
    prob = F.softmax(output)
    nums = len(inputs)
    probs[cnt:cnt+nums] = prob.cpu().data
    cnt = cnt + nums

probs = probs.numpy()
nSam = 10
anchorImages = trImages[0:nSam*10]
anchorLabels = trLabels[0:nSam*10]
tcnt = 0
for i in range(ncls):
    temp = probs[:,i]
    inds = np.argsort(temp)[::-1]
    cnt = -1
    for j in range(len(inds)):
        cnt += 1
        if cnt >= nSam:
            break
        elif trLabels[inds[j]]==i:
            anchorImages[tcnt] = trImages[inds[j]]
            anchorLabels[tcnt] = trLabels[inds[j]]
            tcnt += 1
            print(probs[inds[j]],i,trLabels[inds[j]])

anchor = {}
anchor['anchorImages'] = anchorImages
anchor['anchorLabels'] = anchorLabels
sio.savemat('dataset/mnist/mnist_anchor_images.mat',anchor)
