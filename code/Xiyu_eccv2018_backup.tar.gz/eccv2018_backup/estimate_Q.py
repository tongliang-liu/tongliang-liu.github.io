import scipy.io as sio
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
import torchvision
import copy
import math
import numpy.matlib


from train import *
from evaluation import *
from common_loss import *
from classification_models import *
from utils import *
from flip_rate_estimate import *

use_gpu = torch.cuda.is_available()

foldername = 'without0'
data = sio.loadmat('dataset/mnist/'+foldername+'/mnist_complementary_data_manualwithout0.mat')
trImages = data['trImages']
trLabels = data['trLabels']
valImages = data['valImages']
valLabels = data['valLabels']
tsImages = data['tsImages']
tsLabels = data['tsLabels']

anchordata = sio.loadmat('dataset/mnist/mnist_anchor_images.mat')
anchorImages = anchordata['anchorImages']
anchorLabels = anchordata['anchorLabels']

ncls = 10
Q = np.eye(ncls,ncls)
Q = torch.from_numpy(Q).type(torch.FloatTensor).cuda()
Q = Variable(Q)
trBatch = 128

model_ft = LeNet()
#model_ft = FCNet(784,ncls)
model = copy.deepcopy(model_ft)
if use_gpu:
    model_ft = model_ft.cuda()
    model = model.cuda()

criterion_tr = ForwardLoss(Q)
criterion_val = ForwardLoss(Q)

# first step: validation for learning rate and weight decay
maxiters = 12800
best_lr = -1.0
best_weight_decay = -1.0
best_model = copy.deepcopy(model_ft)

#lrs = [1e-4,1e-3,1e-2]
#decays = [1e-4]
lrs = [1e-3]
decays = [1e-5]

best_val_loss = 1e10
for learning_rate in lrs:
    for decay in decays:
        model_ft = copy.deepcopy(model)
        print("Start training: learning rate {:.4f} and weight decay {:.4f}".format(learning_rate, decay))
        optimizer_ft = optim.Adagrad(model_ft.parameters(), lr=learning_rate, weight_decay=decay)
        total_iters = 0
        while total_iters < maxiters:
            trImages, trLabels = randshuffle(trImages, trLabels)
            model_ft, train_avg_loss, total_iters = train(model_ft, trImages, trLabels, criterion_tr, optimizer_ft, 128, total_iters)
            val_avg_loss, _ = evaluation(model_ft, valImages, valLabels, criterion_val, 1)
            if math.isnan(train_avg_loss):
                break
            if (val_avg_loss < best_val_loss) and (not math.isnan(train_avg_loss)):
                best_val_loss = val_avg_loss
                best_lr = learning_rate
                best_weight_decay = decay
                best_model = copy.deepcopy(model_ft)

            print('Training Loss: {:.4f} Validation Loss: {:.4f}'.format(
                train_avg_loss, val_avg_loss))

print('Best learning rate: {:2.4f} Best weight decay: {:2.4f}'.format(best_lr, best_weight_decay))
Q = flip_rates(best_model, anchorImages, ncls, 1, 1.0, anchorLabels)
print(Q)
estimated_q = {}
estimated_q['Q'] = Q
sio.savemat('dataset/mnist/'+foldername+'/estimated_q_manualwithout0.mat', estimated_q)
