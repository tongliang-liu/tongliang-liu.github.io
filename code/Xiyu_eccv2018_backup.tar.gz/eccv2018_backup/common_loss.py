from __future__ import print_function, division
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torch.autograd import Variable
import copy

def zero_one_loss(z):
    z = torch.sign(-z)
    return torch.clamp(z, min=0.0)

def sigmoid_loss(z):
    return 1.0/(1.0+torch.exp(z))

def ramp_loss(z):
    return 0.5*torch.clamp(1.0-z,min=0.0,max=2.0)

def logistic_loss(z):
    return torch.log(1.0+torch.exp(-z))

def square_loss(z):
    return 0.25*(1.0-z)**2

def hinge_loss(z):
    return torch.clamp(1.0-z, min=0.0)

def ova_loss(x, target, func):
    target = target.view(-1, 1)
    batchsizes = x.size()[0]
    featdim = x.size()[1]
    # something wrong here, it would not be a variable
    tonehot = torch.FloatTensor(x.size()).cuda()
    tonehot.zero_()
    tonehot.scatter_(1,target.data,1)
    tonehot = Variable(tonehot)
    out1 = func(x*tonehot)*tonehot
    tonehot = 1.0 - tonehot
    out2 = func(-x*tonehot)*tonehot
    loss = (out1.sum() + out2.sum()/(featdim-1.0))/(batchsizes*1.0)

    return loss

def complementary_ova_loss(x, target, func):
    target = target.view(-1, 1)
    batchsizes = x.size()[0]
    featdim = x.size()[1]
    # something wrong here, it would not be a variable
    tonehot = torch.FloatTensor(x.size()).cuda()
    tonehot.zero_()
    tonehot.scatter_(1,target.data,1)
    tonehot = Variable(tonehot)
    out1 = func(-x*tonehot)*tonehot
    tonehot = 1.0 - tonehot
    out2 = func(x*tonehot)*tonehot
    loss = (out1.sum() + out2.sum()/(featdim-1.0))/(batchsizes*1.0)

    return loss

def pc_loss(x, target, func):
    target = target.view(-1, 1)
    batchsizes = x.size()[0]
    tonehot = torch.FloatTensor(x.size()).cuda()
    tonehot.zero_()
    tonehot.scatter_(1,target.data,1)
    tonehot = Variable(tonehot)
    out = tonehot*x
    out = out.sum(1).view(-1,1).expand_as(x)
    out = out - x
    out = func(out)
    tonehot = 1.0 - tonehot
    out = out*tonehot
    loss = out.sum()/(batchsizes*1.0)
    
    return loss

def complementary_pc_loss(x, target, func):
    target = target.view(-1, 1)
    batchsizes = x.size()[0]
    tonehot = torch.FloatTensor(x.size()).cuda()
    tonehot.zero_()
    tonehot.scatter_(1,target.data,1)
    tonehot = Variable(tonehot)
    out = tonehot*x
    out = out.sum(1).view(-1,1).expand_as(x)
    out = x - out
    out = func(out)
    tonehot = 1.0 - tonehot
    out = out*tonehot
    loss = out.sum()/(batchsizes*1.0)
    
    return loss

class OVALoss(nn.Module):
    """OVA loss function.
    we need give the binary loss."""
    def __init__(self, binaryloss):
        super(OVALoss, self).__init__()
        self.binaryloss = binaryloss

    def forward(self, x, target):
        target = target.view(-1, 1)
        batchsizes = x.size()[0]
        featdim = x.size()[1]
        # something wrong here, it would not be a variable
        tonehot = torch.FloatTensor(x.size()).cuda()
        tonehot.zero_()
        tonehot.scatter_(1,target.data,1)
        tonehot = Variable(tonehot)
        out1 = self.binaryloss(x*tonehot)*tonehot
        tonehot = tonehot - 1.0
        out2 = self.binaryloss(x*tonehot)*(-tonehot)
        loss = (out1.sum() + out2.sum()/(featdim-1.0))/(batchsizes*1.0)
        
        return loss

class ComplementaryOVALoss(nn.Module):
    def __init__(self, binaryloss):
        super(ComplementaryOVALoss, self).__init__()
        self.binaryloss = binaryloss
    
    def forward(self, x, target):
        target = target.view(-1, 1)
        batchsizes = x.size()[0]
        featdim = x.size()[1]
        # something wrong here, it would not be a variable
        tonehot = torch.FloatTensor(x.size()).cuda()
        tonehot.zero_()
        tonehot.scatter_(1,target.data,1)
        tonehot = Variable(tonehot)
        out1 = self.binaryloss(-x*tonehot)*tonehot
        tonehot = 1.0 - tonehot
        out2 = self.binaryloss(x*tonehot)*tonehot
        loss = (out1.sum() + out2.sum()/(featdim-1.0))/(batchsizes*1.0)

        return loss

class PCLoss(nn.Module):
    """pairwise comparison loss function.
    we need give the binary loss."""
    def __init__(self, binaryloss):
        super(PCLoss, self).__init__()
        self.binaryloss = binaryloss

    def forward(self, x, target):
        target = target.view(-1, 1)
        batchsizes = x.size()[0]
        tonehot = torch.FloatTensor(x.size()).cuda()
        tonehot.zero_()
        tonehot.scatter_(1,target.data,1)
        tonehot = Variable(tonehot)
        out = tonehot*x
        out = out.sum(1).view(-1,1).expand_as(x)
        out = out - x
        out = self.binaryloss(out)
        tonehot = 1.0 - tonehot
        out = out*tonehot
        loss = out.sum()/(batchsizes*1.0)

        return loss


class ComplementaryPCLoss(nn.Module):
    def __init__(self, binaryloss):
        super(ComplementaryPCLoss, self).__init__()
        self.binaryloss = binaryloss

    def forward(self, x, target):
        target = target.view(-1, 1)
        batchsizes = x.size()[0]
        tonehot = torch.FloatTensor(x.size()).cuda()
        tonehot.zero_()
        tonehot.scatter_(1,target.data,1)
        tonehot = Variable(tonehot)
        out = tonehot*x
        out = out.sum(1).view(-1,1).expand_as(x)
        out = x - out
        out = self.binaryloss(out)
        tonehot = 1.0 - tonehot
        out = out*tonehot
        loss = out.sum()/(batchsizes*1.0)

        return loss

class ComplementaryPC2Loss(nn.Module):
    def __init__(self, binaryloss):
        super(ComplementaryPC2Loss, self).__init__()
        self.binaryloss = binaryloss

    def forward(self, x, target):
        rows = np.range(len(target))
        rows = torch.from_numpy(rows).type(torch.LongTensor).cuda
        rows = Variable(rows)
        for y in target:
            i += 1
            for v in x[i]:
                x[i,j] = self.binaryloss(x[i,j]-x[i,target[i]])

        loss = x.sum()
        return loss


class ForwardLoss(nn.Module):
    def __init__(self, Q):
        super(ForwardLoss, self).__init__()
        self.Q = Q
       
    def forward(self, x, target):
        #print(x,target)
        probt = F.softmax(x)
        #print(probt)
        prob = torch.mm(probt,self.Q)
        #print(prob)
        out = torch.log(prob)
        #print(out)
        loss = F.nll_loss(out,target)
        #print(loss)
        return loss
