import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
import torchvision

use_gpu = torch.cuda.is_available()

def evaluation(model, tsImages, tsLabels, criterion, batch_size=1):
    avg_loss = 0.0
    avg_acc = 0.0
    nTest = 0

    nIters = int(len(tsLabels)/batch_size)
    for iters in range(nIters):
        inputs = tsImages[iters*batch_size:(iters+1)*batch_size]
        labels = tsLabels[iters*batch_size:(iters+1)*batch_size]
        nTest += len(labels)

        inputs = torch.from_numpy(inputs).type(torch.FloatTensor)
        labels = torch.from_numpy(labels).type(torch.LongTensor)
        labels = torch.squeeze(labels)
        if use_gpu:
            inputs, labels = Variable(inputs.cuda()), Variable(labels.cuda())
        else:
            inputs, labels = Variable(inputs), Variable(labels)

        output = model(inputs)
        _, preds = torch.max(output.data, 1)
        loss = criterion(output, labels)

        avg_loss += loss.data[0]
        avg_acc += torch.sum(preds == labels.data)

    avg_loss /= (nTest*1.0+1e-6)
    avg_acc /= (nTest*1.0+1e-6)

    return avg_loss, avg_acc


def evaluation2(model, tsImages, tsLabels, criterion, batch_size=1):
    avg_loss = 0.0
    avg_acc = 0.0
    nTest = 0

    nIters = int(len(tsLabels)/batch_size)
    for iters in range(nIters):
        inputs = tsImages[iters*batch_size:(iters+1)*batch_size]
        labels = tsLabels[iters*batch_size:(iters+1)*batch_size]
        nTest += len(labels)

        inputs = torch.from_numpy(inputs).type(torch.FloatTensor)
        labels = torch.from_numpy(labels).type(torch.LongTensor)
        labels = torch.squeeze(labels)
        if use_gpu:
            inputs, labels = Variable(inputs.cuda()), Variable(labels.cuda())
        else:
            inputs, labels = Variable(inputs), Variable(labels)

        output = model(inputs)
        _, preds = torch.min(output.data, 1)
        loss = criterion(output, labels)
        
        avg_loss += loss.data[0]
        avg_acc += torch.sum(preds == labels.data)

    avg_loss /= (nTest*1.0+1e-6)
    avg_acc /= (nTest*1.0+1e-6)

    return avg_loss, avg_acc
