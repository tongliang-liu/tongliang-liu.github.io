function beta = betaKMM_targetshift_simple(X, Y, Xtst, Ytst, sigma, width_L_beta, lambda_beta)
% function [beta EXITFLAG] = betaKMM_targetshift(X, Y, Xtst, Ytst, sigma, width_L_beta, lambda_beta);
% This function estimates the weight \beta for correcting for target
% shift.
% Input:
%       X: features on training domain (size: # training data points * # dimensions);
%       Y: target on training domain (size: # training data points * 1);
%       Xtst: features on test domain (size: # test data points * # dimensions);
%       Ytst: target on training domain (size: # tset data points * 1);
%       sigma: the kernel width for X used to construct Gram matrix K;
%       width_L_beta & lambda_beta: the kernel width and regularization
%       parameter lambda_beta used for L_beta for continuous Y (regression).
% Outut:
%       beta: estimated weights (size: # training data points * # dimensions);


nsamples = size(X,1);  % number of train samples
ntestsamples = size(Xtst,1);  % number of test samples

options = optimset('MaxIter', 100); % 5000
Thresh_beta = 1E-3; %2E-1; % 1E-3
Thresh_discrete = 35;

dd = size(X,2);
if ~exist('sigma', 'var')||isempty(sigma)
    if nsamples < 500
        sigma = 0.4 * sqrt(dd); %1E-1; % 1E-3
    elseif nsamples < 1000
        sigma = 0.2 * sqrt(dd);
    else
        sigma = 0.14 * sqrt(dd);
    end
end


% variables: (here in the program / in (12) in the paper)
% H is K
% f is kappa
%

% minimize...
% 'calculating H=K...'
if size(X,2) > 1E4
    mean_std_x = mean(std(X(:,1:10:end)));
else
    mean_std_x = mean(std(X));
end
H = rbf_dot(X,X,sigma,0);
H=(H+H')/2; %make the matrix symmetric (it isn't symmetric before because of bad precision)


% 'calculating f=kappa...'
R3 = rbf_dot(X,Xtst,sigma,0);
M= R3*ones(ntestsamples, 1);
M=-nsamples/ntestsamples*M;

options.Display = 'off';
% is Y discrete or continous ?
UB_beta = 10; % the maximum value of beta
% calculate the cardinality of Y and its possible values:
Card_Y = 1;
Val_Y = [];
Val_Y(1) = Y(1);
for i=2:nsamples
    if ~max(Y(i)==Val_Y)
        Val_Y = [Val_Y Y(i)];
        Card_Y = Card_Y + 1;
        if Card_Y > Thresh_discrete % continuous, so no need to calculate the cardinality.
            break;
        end
    end
end
if Card_Y < Thresh_discrete+1
    fprintf('Y is discrete; calculateing beta is easier...\n');
    R = zeros(nsamples, Card_Y);
    for i = 1:nsamples
        R(i,Y(i) == Val_Y)  = 1;
    end
    % lb_sum_beta = 0.95; ub_sum_beta = 1.05;
    B = UB_beta; lb_sum_beta = 1-B/sqrt(nsamples)/4; ub_sum_beta =  1+B/sqrt(nsamples)/4;
    A = [-R; R; ones(1,nsamples)*R; -ones(1,nsamples)*R];
    b = [zeros(nsamples, 1)-Thresh_beta; ones(nsamples,1)*UB_beta;ub_sum_beta*nsamples; -lb_sum_beta*nsamples]; % 0.02
    RH = R'*H*R;
    RH = (RH + RH')/2;
    [alpha, FVAL, EXITFLAG, output] = quadprog(RH, R'*M, A, b,...
        [], [], zeros(Card_Y,1), 100*ones(Card_Y,1),[], options);
    beta = max(R * alpha, Thresh_beta);
else
    fprintf('Y is continuous; please wait a while for beta values...\n');
    lambda2 = 0.1; %0.1
    % re-calculate the kernel matrix on Y?
    %     KY = (KY_x + KY_x')/2;
    %         Width_KY = width*mean(std(Y)) * 3; %2
    Width_KY = width_L_beta;
    lambda2 = lambda_beta;
    KY = rbf_dot(Y,Y,Width_KY,0);
    KY = (KY + KY')/2;
    
    if nsamples < 600
        Q = KY * pdinv(KY + lambda2 * eye(nsamples));
        alpha0 = ones(nsamples,1);
    else
        pdinv_KY = pdinv(KY + lambda2 * eye(nsamples));
        %         [eig1, ei1] = eigdec(KY * pdinv_KY * pdinv_KY'*KY', min(300, floor(nsamples/4))); % /2
        %         II1 = find(eig1 > max(eig1) * Thresh); eig1 = eig1(II1); ei1 = ei1(:,II1);
        %         R = ei1 * diag(sqrt(eig1));
        [UU1,SS1,VV1] = svd(KY *pdinv_KY);
        eig1 = diag(SS1);
        II1 = find(eig1 > max(eig1) * Thresh);
        Q = KY*pdinv_KY * VV1(:,II1);
        alpha0 = pdinv(Q'*Q) * Q'* ones(nsamples,1);
    end
    
    
    %     [alpha, FVAL, EXITFLAG] = quadprog(Q'*J*Q, Q'*M, -Q, zeros(nsamples, 1),...
    %         ones(1,nsamples)*Q, nsamples, -1000*ones(nsamples,1), 1000*ones(nsamples,1),[], options);
    
    %         lb_sum_beta = 0.8; ub_sum_beta = 1.2;
    B = 10; lb_sum_beta = 1-B/sqrt(nsamples)/4; ub_sum_beta =  1+B/sqrt(nsamples)/4;
    A = [-Q; Q; ones(1,nsamples)*Q; -ones(1,nsamples)*Q];
    b = [zeros(nsamples, 1)-Thresh_beta; ones(nsamples,1)*UB_beta; ub_sum_beta*nsamples; -lb_sum_beta*nsamples]; % 0.02
    [alpha, FVAL, EXITFLAG] = quadprog(Q'*H*Q, Q'*M, A, b,...
        [], [], -1E4*ones(size(Q,2),1), 1E4*ones(size(Q,2),1),alpha0, options);
    beta = max(Q * alpha, Thresh_beta);
end
end
