function df = dFLS_LS(Y)
% dF	Computes the differential of F, that is,
% 	de satisfies real(trace(H'*df)) = d/dx (F(B+x*H)).
%
%	df = DF(B)
%	B is expected to satisfy B'*B = I
%	df is the same size as B
%
% role	objective function, this is the routine called to compute the
%	differential of F.
global FParameters;
A = FParameters.A;
B = FParameters.B;
W = FParameters.W;
sigma= FParameters.sigma;
ru= FParameters.ru;
cnt= FParameters.cnt;
Asvm= FParameters.Asvm;
cntsemi= FParameters.cntsemi;
beta = FParameters.beta;
L_y =  FParameters.L;
lambdaTip = FParameters.lambdaTip;
lambdaLS = FParameters.lambdaLS;
lambdaMMD = FParameters.lambdaMMD;
epsilon = FParameters.epsilon;
C = numel(cnt);
Sc = Y(:,1:C);
Lo = Y(:,C+1:2*C);
[ScE, LoE] = matrixLS(Sc, Lo, cnt);
A = W'*A;
B = W'*B;
n1=size(A,2);
n2=size(B,2);
D = dist2(A'.*ScE'+LoE',B');
D1 = dist2(A'.*ScE'+LoE',A'.*ScE'+LoE');
D2 = dist2(B',B');

distx=exp(-D1./sigma);
disty=exp(-D2./sigma);
distxy=exp(-D./sigma);
Lii=beta*beta'./(n1^2);
Ljj=ones(n2)./(n2^2);
Lij=beta*ones(1,n2)./(n1*n2);
distx1 = distx.*Lii;
disty = disty.*Ljj;
distxy = distxy.*Lij;

deriv1tmp1 = zeros(size(Y));
AA = ScE.*A;
R1 = repmat(AA,1,n1);
Z1 = repmat(AA,n1,1);
J1 = reshape(Z1,size(AA,1),[]);
R1J1 = J1 - R1;
B1 = repmat(LoE,1,n1);
b1 = repmat(LoE,n1,1);
b1 = reshape(b1,size(LoE,1),[]);
B1b1 = b1 - B1;
alphatmp1=reshape(distx1,1,[]);
alpha1=repmat(alphatmp1,size(A,1),1);
deriv1tmp1Sc = 4*(R1J1+B1b1).*alpha1.*reshape(repmat(A,n1,1),size(A,1),[]);
deriv1tmp1Lo = 4*(R1J1+B1b1).*alpha1;
for c = 1:C
    deriv1tmp1(:,c) = sum(deriv1tmp1Sc(:,sum(cnt(1:c-1))*n1+1:sum(cnt(1:c))*n1),2);   
    deriv1tmp1(:,C+c) = sum(deriv1tmp1Lo(:,sum(cnt(1:c-1))*n1+1:sum(cnt(1:c))*n1),2);
end

deriv3tmp3 = zeros(size(Y));
R3 = repmat(B,1,n1);
Z3 = repmat(AA,n2,1);
J3 = reshape(Z3,size(AA,1),[]);
R3J3 = J3 - R3;
b3 = repmat(LoE,n2,1);
b3 = reshape(b3,size(LoE,1),[]);
alphatmp3=reshape(distxy',1,[]);
alpha3=repmat(alphatmp3,size(A,1),1);
deriv3tmp3Sc = 4*(R3J3+b3).*alpha3.*reshape(repmat(A,n2,1),size(A,1),[]);
deriv3tmp3Lo = 4*(R3J3+b3).*alpha3;
for c = 1:C
    deriv3tmp3(:,c) = sum(deriv3tmp3Sc(:,sum(cnt(1:c-1))*n2+1:sum(cnt(1:c))*n2),2);   
    deriv3tmp3(:,C+c) = sum(deriv3tmp3Lo(:,sum(cnt(1:c-1))*n2+1:sum(cnt(1:c))*n2),2);
end

if lambdaTip ~= 0
    derivReg1 = zeros(size(Y));
    LL = -epsilon*pdinv(distx+n1*epsilon*eye(n1))*L_y*pdinv(distx+n1*epsilon*eye(n1));
    distx = distx.*LL;
    alphatmp4=reshape(distx,1,[]);
    alpha4=repmat(alphatmp4,size(A,1),1);
    deriv4tmp4Sc = -4*(R1J1+B1b1).*alpha4.*reshape(repmat(A,n1,1),size(A,1),[]);
    deriv4tmp4Lo = -4*(R1J1+B1b1).*alpha4;
    for c = 1:C
        derivReg1(:,c) = sum(deriv4tmp4Sc(:,sum(cnt(1:c-1))*n1+1:sum(cnt(1:c))*n1),2);
        derivReg1(:,C+c) = sum(deriv4tmp4Lo(:,sum(cnt(1:c-1))*n1+1:sum(cnt(1:c))*n1),2);
    end
else
    derivReg1 = 0;
end

% c=mat2cell(Asvm,size(A,1),cntsemi);
reg=zeros(size(Y));
% for i = 1 : size(c,2)
%     mu=repmat(mean(c{i},2),1,size(c{i},2));
%     reg = reg+ 2*(c{i}-mu)*(c{i}-mu)'*Y;
% end
df=lambdaMMD*(deriv3tmp3-deriv1tmp1)./sigma+ru*reg+lambdaTip*derivReg1./sigma + ...
    [2*lambdaLS(1)*(Sc-ones(size(Sc))),2*lambdaLS(2)*Lo];