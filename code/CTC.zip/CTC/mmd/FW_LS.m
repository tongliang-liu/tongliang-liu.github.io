function f = FW_LS(Y)
% F_S Computes the energy associated with the stieffel point Y.
% 	In this case, by the equation f = trace(Y'AY)/2.
%
%	f = F_LS(Y) add location scale transformation
%	Y is expected to satisfy Y'*Y=I
%
% role	objective function, the routine called to compute the objective 
%	function.
	global FParameters;
	A = FParameters.A;
    B=  FParameters.B;
    ScE = FParameters.ScE;
    LoE = FParameters.LoE;
    Sc = FParameters.Sc;
    Lo = FParameters.Lo;
    sigma= FParameters.sigma;
    ru= FParameters.ru;
    cnt= FParameters.cnt;
    Asvm= FParameters.Asvm;
    cntsemi= FParameters.cntsemi;
    beta = FParameters.beta;
    L_y =  FParameters.L;
    lambdaLS = FParameters.lambdaLS;
    lambdaTip = FParameters.lambdaTip;
    lambdaMMD = FParameters.lambdaMMD;
    epsilon = FParameters.epsilon;
    f = computeMMD(ScE.*(Y'*A)+LoE,Y'*B,sigma,ru,cnt,Y'*Asvm,cntsemi,beta,L_y,lambdaTip,lambdaMMD,epsilon);
    f1 = lambdaLS(1)*norm(Sc-ones(size(Sc)),'fro').^2 + lambdaLS(2)*norm(Lo,'fro').^2;
    f = f+f1;