function f = F(Y)
% F	Computes the CIC energy associated with the stieffel point Y.
% 	In this case, by the equation f = trace(Y'AY)/2.
%
%	f = F(Y)
%	Y is expected to satisfy Y'*Y=I
%
%   objective function, the routine called to compute the objective
%	function.
global FParameters;
A = FParameters.A;
B=  FParameters.B;
sigma= FParameters.sigma;
ru= FParameters.ru;
cnt= FParameters.cnt;
Asvm= FParameters.Asvm;
cntsemi= FParameters.cntsemi;
beta = FParameters.beta;
L_y =  FParameters.L;
lambdaTip = FParameters.lambdaTip;
lambdaMMD = FParameters.lambdaMMD;
epsilon = FParameters.epsilon;
XA = Y'*A;
XB = Y'*B;
f = computeMMD(XA,XB,sigma,ru,cnt,Y'*Asvm,cntsemi,beta,L_y,lambdaTip,lambdaMMD,epsilon);
