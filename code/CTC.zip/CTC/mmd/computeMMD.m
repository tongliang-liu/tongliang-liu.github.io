function [mmd,distx,disty] = computeMMD(X,Y,sigma,ru,cnt,Xsvm,cntsemi,beta,L_y,lambdaTip,lambdaMMD,epsilon)

n1=size(X,2);
n2=size(Y,2);

D = dist2(X',Y');
if(nargin<3) || (isempty(sigma)) || (sigma<=0)
    sigma = median(D(D~=0));
end

Lii=beta*beta'./(n1^2);
Ljj=ones(n2)./(n2^2);
Lij=beta*ones(1,n2)./(-n1*n2);
L=[Lii Lij; Lij' Ljj];

D1 = dist2(X',X');
D2 = dist2(Y',Y');

distx=exp(-D1./sigma);
disty=exp(-D2./sigma);
distxy=exp(-D./sigma);

reg=0;
% c=mat2cell(Xsvm,size(X,1),cntsemi);
% for i = 1 : size(c,2)
%     reg = reg+ sum (dist2(c{i}',mean(c{i},2)'));
% end    
K=[distx distxy; distxy' disty];
if lambdaTip~=0
    regTip = epsilon*trace(L_y*pdinv(distx+n1*epsilon*eye(n1))); % tip regularization
else
    regTip = 0;
end
mmd=lambdaMMD*trace(K*L)+ru*reg+lambdaTip*regTip;

