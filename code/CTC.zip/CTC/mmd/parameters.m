function parameters(A,B,sigma,ru,cnt,Asvm,cntsemi,beta,L,lambdaTip,lambdaMMD,epsilon)
% PARAMETERS	initializes the parameters for an instance of a
%		minimization problem.
%
%	PARAMETERS(A)
%	A is expected to be a square matrix
%
% role	sets up the global parameters used at all levels of computation.

global FParameters;
FParameters = [];
FParameters.A = A;
FParameters.B = B;
FParameters.sigma = sigma;
FParameters.ru = ru;
FParameters.cnt = cnt;
FParameters.Asvm = Asvm;
FParameters.cntsemi = cntsemi;
FParameters.beta = beta;
FParameters.L = L;
FParameters.lambdaTip = lambdaTip;
FParameters.lambdaMMD = lambdaMMD;
FParameters.epsilon = epsilon;
