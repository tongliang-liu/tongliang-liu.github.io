function f = FLS_LS(Y)
% F_S Computes the energy associated with the stieffel point Y.
% 	In this case, by the equation f = trace(Y'AY)/2.
%
%	f = F_LS(Y) add location scale transformation
%	Y is expected to satisfy Y'*Y=I
%
% role	objective function, the routine called to compute the objective 
%	function.
	global FParameters;
	A = FParameters.A;
    B =  FParameters.B;
    W = FParameters.W;
    sigma= FParameters.sigma;
    ru= FParameters.ru;
    cnt= FParameters.cnt;
    Asvm= FParameters.Asvm;
    cntsemi= FParameters.cntsemi;
    beta = FParameters.beta;
    L_y =  FParameters.L;
    lambdaLS = FParameters.lambdaLS;
    lambdaTip = FParameters.lambdaTip;
    lambdaMMD = FParameters.lambdaMMD;
    epsilon = FParameters.epsilon;
    C = numel(cnt);
    [ScE, LoE] = matrixLS(Y(:,1:C), Y(:,C+1:2*C), cnt);
	f = computeMMD(ScE.*(W'*A)+LoE,W'*B,sigma,ru,cnt,W'*Asvm,cntsemi,beta,L_y,lambdaTip,lambdaMMD,epsilon);
    f1 = lambdaLS(1)*norm(Y(:,1:C)-ones(size(Y(:,1:C))),'fro').^2 + lambdaLS(2)*norm(Y(:,C+1:2*C),'fro').^2;
    f = f+f1;