function df = dF(Y)
% dF	Computes the differential of F, that is,
% 	de satisfies real(trace(H'*df)) = d/dx (F(B+x*H)).
%
%	df = dF(Y)
%	B is expected to satisfy Y'*Y = I
%	df is the same size as Y
%
%   objective function, this is the routine called to compute the
%	differential of F.

global FParameters;
A = FParameters.A;
B = FParameters.B;
sigma= FParameters.sigma;
ru= FParameters.ru;
cnt= FParameters.cnt;
Asvm= FParameters.Asvm;
cntsemi= FParameters.cntsemi;
beta = FParameters.beta;
L_y =  FParameters.L;
lambdaTip = FParameters.lambdaTip;
lambdaMMD = FParameters.lambdaMMD;
epsilon = FParameters.epsilon;

n1=size(A,2);
n2=size(B,2);

D = dist2(A'*Y,B'*Y);
D1 = dist2(A'*Y,A'*Y);
D2 = dist2(B'*Y,B'*Y);

distx=exp(-D1./sigma);
disty=exp(-D2./sigma);
distxy=exp(-D./sigma);
Lii=beta*beta'./(n1^2);
Ljj=ones(n2)./(n2^2);
Lij=beta*ones(1,n2)./(n1*n2);
distx1 = distx.*Lii;
disty = disty.*Ljj;
distxy = distxy.*Lij;

R1=repmat(A,1,n1);
Z1=repmat(A,n1,1);
J1=reshape(Z1,size(A,1),[]);
alphatmp1=reshape(distx1,1,[]);
alpha1=repmat(alphatmp1,size(A,1),1);
deriv1tmp1=2*((R1-J1).*alpha1*(R1-J1)')*Y;

R2=repmat(B,1,n2);
Z2=repmat(B,n2,1);
J2=reshape(Z2,size(B,1),[]);
alphatmp2=reshape(disty,1,[]);
alpha2=repmat(alphatmp2,size(B,1),1);
deriv2tmp2=2*((R2-J2).*alpha2*(R2-J2)')*Y;

R3=repmat(A,1,n2);
Z3=repmat(B,n1,1);
J3=reshape(Z3,size(B,1),[]);
alphatmp3=reshape(distxy,1,[]);
alpha3=repmat(alphatmp3,size(B,1),1);
deriv3tmp3=4*((R3-J3).*alpha3*(R3-J3)')*Y;

if lambdaTip ~= 0
    LL = -epsilon*pdinv(distx+n1*epsilon*eye(n1))*L_y*pdinv(distx+n1*epsilon*eye(n1));
    distx = distx.*LL;
    alphatmp4=reshape(distx,1,[]);
    alpha4=repmat(alphatmp4,size(A,1),1);
    derivRegTip=-2*((R1-J1).*alpha4*(R1-J1)')*Y;
else
    derivRegTip = 0;
end

% c=mat2cell(Asvm,size(A,1),cntsemi);
reg=zeros(size(Y));
% for i = 1 : size(c,2)
%     mu=repmat(mean(c{i},2),1,size(c{i},2));
%     reg = reg+ 2*(c{i}-mu)*(c{i}-mu)'*Y;
% end
df=lambdaMMD*(deriv3tmp3./(sigma)-deriv1tmp1./(sigma)-deriv2tmp2./(sigma))+ru*reg+lambdaTip*derivRegTip./sigma;
% df=deriv3tmp3./(n1*n2*sigma)-deriv1tmp1./(n1^2*sigma)-deriv2tmp2./(n2^2*sigma)+ru*reg;