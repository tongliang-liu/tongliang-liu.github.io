function [ScE, LoE] = matrixLS(Sc, Lo, cnt)
[d, C] = size(Sc);
n = sum(cnt);
ScE = zeros(d,n);
LoE = zeros(d,n);
for i = 1:C
    ScE(:,sum(cnt(1:i-1))+1:sum(cnt(1:i))) = repmat(Sc(:,i),[1 cnt(i)]);
    LoE(:,sum(cnt(1:i-1))+1:sum(cnt(1:i))) = repmat(Lo(:,i),[1 cnt(i)]);
end