function df = dFW_LS(Y)
% dF	Computes the differential of F, that is,
% 	de satisfies real(trace(H'*df)) = d/dx (F(B+x*H)).
%
%	df = DF(B)
%	B is expected to satisfy B'*B = I
%	df is the same size as B
%
% role	objective function, this is the routine called to compute the
%	differential of F.
global FParameters;
A = FParameters.A;
B = FParameters.B;
Sc = FParameters.Sc;
Lo = FParameters.Lo;
ScE = FParameters.ScE;
LoE = FParameters.LoE;
sigma= FParameters.sigma;
ru= FParameters.ru;
cnt= FParameters.cnt;
Asvm= FParameters.Asvm;
cntsemi= FParameters.cntsemi;
beta = FParameters.beta;
L_y =  FParameters.L;
lambdaTip = FParameters.lambdaTip;
lambdaMMD = FParameters.lambdaMMD;
epsilon = FParameters.epsilon;

n1=size(A,2);
n2=size(B,2);
D = dist2(A'*Y.*ScE'+LoE',B'*Y);
D1 = dist2(A'*Y.*ScE'+LoE',A'*Y.*ScE'+LoE');
D2 = dist2(B'*Y,B'*Y);

distx=exp(-D1./sigma);
disty=exp(-D2./sigma);
distxy=exp(-D./sigma);
Lii=beta*beta'./(n1^2);
Ljj=ones(n2)./(n2^2);
Lij=beta*ones(1,n2)./(n1*n2);
distx1 = distx.*Lii;
disty = disty.*Ljj;
distxy = distxy.*Lij;
if size(Y,2) <= 5
    deriv1tmp1 = zeros(size(Y));
    deriv3tmp3 = zeros(size(Y));
    alphatmp1=reshape(distx1,1,[]);
    alpha1=repmat(alphatmp1,size(A,1),1);
    Z3=repmat(B,n1,1);
    J3=reshape(Z3,size(B,1),[]);
    alphatmp3=reshape(distxy,1,[]);
    alpha3=repmat(alphatmp3,size(B,1),1);
    LoER = repmat(LoE,1,n1);
    LoER3 = repmat(LoE,1,n2);
    LoEZ = repmat(LoE,n1,1);
    LoEZ = reshape(LoEZ,size(LoE,1),[]);
    LoERZ = LoER - LoEZ;
    for i = 1:size(Y,2)
        AA = repmat(ScE(i,:),size(Y,1),1).*A;
        R1=repmat(AA,1,n1);
        Z1=repmat(AA,n1,1);
        J1=reshape(Z1,size(AA,1),[]);
        R1J1 = R1-J1;
        deriv1tmp1(:,i)=2*((R1J1).*alpha1*(R1J1)')*Y(:,i)+ ...
            2*sum(R1J1.*alpha1.*repmat(LoERZ(i,:),size(A,1),1),2);
        R3=repmat(AA,1,n2);
        R3J3 = R3-J3;
        deriv3tmp3(:,i)=4*((R3J3).*alpha3*(R3J3)')*Y(:,i)+ ...
            4*sum(R3J3.*alpha3.*repmat(LoER3(i,:),size(B,1),1),2);
    end
    
    R2=repmat(B,1,n2);
    Z2=repmat(B,n2,1);
    J2=reshape(Z2,size(B,1),[]);
    alphatmp2=reshape(disty,1,[]);
    alpha2=repmat(alphatmp2,size(B,1),1);
    deriv2tmp2=2*((R2-J2).*alpha2*(R2-J2)')*Y;
    
    if lambdaTip ~= 0
        derivReg1 = zeros(size(Y));
        LL = -epsilon*pdinv(distx+n1*epsilon*eye(n1))*L_y*pdinv(distx+n1*epsilon*eye(n1));
        distx4 = distx.*LL;
        alphatmp4=reshape(distx4,1,[]);
        alpha4=repmat(alphatmp4,size(A,1),1);
        for i = 1:size(Y,2)
            AA = repmat(ScE(i,:),size(Y,1),1).*A;
            R1=repmat(AA,1,n1);
            Z1=repmat(AA,n1,1);
            J1=reshape(Z1,size(AA,1),[]);
            R1J1 = R1-J1;
            derivReg1(:,i)=-2*((R1J1).*alpha4*(R1J1)')*Y(:,i)- ...
                2*sum(R1J1.*alpha4.*repmat(LoERZ(i,:),size(A,1),1),2);
        end
    else
        derivReg1 = 0;
    end
    
else
    %% maybe faster implementation
    C = numel(cnt);
    R1J1Alpha1 = zeros(size(A,1),size(A,1),C^2);
    R1J1Alpha2 = zeros(size(A,1),size(A,1),C^2);
    R1J1Alpha3 = zeros(size(A,1),size(A,1),C^2);
    R1J1Alpha4 = zeros(size(A,1),size(A,1),C^2);
    ind = 1;
    for c2 = 1:C
        for c1 = 1:C
            Ac1 = A(:,sum(cnt(1:c1-1))+1:sum(cnt(1:c1)));
            Ac2 = A(:,sum(cnt(1:c2-1))+1:sum(cnt(1:c2)));
            R1 = repmat(Ac1,1,size(Ac2,2));
            Z1 = repmat(Ac2,size(Ac1,2),1);
            J1 = reshape(Z1,size(A,1),[]);
            alphatmp1=reshape(distx1(sum(cnt(1:c1-1))+1:sum(cnt(1:c1)), ...
                sum(cnt(1:c2-1))+1:sum(cnt(1:c2))),1,[]);
            alpha1=repmat(alphatmp1,size(A,1),1);
            R1J1Alpha1(:,:,ind) = 2*R1.*alpha1*R1';
            R1J1Alpha2(:,:,ind) = 2*J1.*alpha1*J1';
            R1J1Alpha3(:,:,ind) = 2*R1.*alpha1*J1';
            R1J1Alpha4(:,:,ind) = 2*J1.*alpha1*R1';
            ind = ind + 1;
        end
    end
    
    alphatmp1=reshape(distx1,1,[]);
    alpha1=repmat(alphatmp1,size(A,1),1);
    LoER = repmat(LoE,1,n1);
    LoEZ = repmat(LoE,n1,1);
    LoEZ = reshape(LoEZ,size(LoE,1),[]);
    LoERZ = LoER - LoEZ;
    deriv1tmp1 = zeros(size(Y));
    for i = 1:size(Y,2)
        lambda1 = repmat((Sc(i,:).*Sc(i,:))',[1 C]);
        lambda2 = repmat(Sc(i,:).*Sc(i,:),[C 1]);
        lambda3 = Sc(i,:)'*Sc(i,:);
        lambda4 = lambda3;
        lambda1 = repmat(reshape(lambda1(:),1,1,numel(lambda1(:))),size(A,1),size(A,1));
        lambda2 = repmat(reshape(lambda2(:),1,1,numel(lambda2(:))),size(A,1),size(A,1));
        lambda3 = repmat(reshape(lambda3(:),1,1,numel(lambda3(:))),size(A,1),size(A,1));
        lambda4 = repmat(reshape(lambda4(:),1,1,numel(lambda4(:))),size(A,1),size(A,1));
        AA = repmat(ScE(i,:),size(Y,1),1).*A;
        R1=repmat(AA,1,n1);
        Z1=repmat(AA,n1,1);
        J1=reshape(Z1,size(AA,1),[]);
        R1J1 = R1-J1;
        deriv1tmp1(:,i) = sum(R1J1Alpha1.*lambda1 + R1J1Alpha2.*lambda2 - ...
            R1J1Alpha3.*lambda3 - R1J1Alpha4.*lambda4,3)*Y(:,i) + ...
            2*sum(R1J1.*alpha1.*repmat(LoERZ(i,:),size(A,1),1),2);
    end
    
    R3J3Alpha1 = zeros(size(A,1),size(A,1),C);
    R3J3Alpha2 = zeros(size(A,1),size(A,1),C);
    R3J3Alpha3 = zeros(size(A,1),size(A,1),C);
    R3J3Alpha4 = zeros(size(A,1),size(A,1),C);
    ind = 1;
    for c1 = 1:C
        Ac1 = A(:,sum(cnt(1:c1-1))+1:sum(cnt(1:c1)));
        R3 = repmat(Ac1,1,size(B,2));
        Z3 = repmat(B,size(Ac1,2),1);
        J3 = reshape(Z3,size(B,1),[]);
        alphatmp3=reshape(distxy(sum(cnt(1:c1-1))+1:sum(cnt(1:c1)),:),1,[]);
        alpha3=repmat(alphatmp3,size(A,1),1);
        R3J3Alpha1(:,:,ind) = 4*R3.*alpha3*R3';
        R3J3Alpha2(:,:,ind) = 4*J3.*alpha3*J3';
        R3J3Alpha3(:,:,ind) = 4*R3.*alpha3*J3';
        R3J3Alpha4(:,:,ind) = 4*J3.*alpha3*R3';
        ind = ind + 1;
    end
    
    alphatmp3=reshape(distxy,1,[]);
    alpha3=repmat(alphatmp3,size(B,1),1);
    LoER3 = repmat(LoE,1,n2);
    Z3=repmat(B,n1,1);
    J3=reshape(Z3,size(B,1),[]);
    deriv3tmp3 = zeros(size(Y));
    for i = 1:size(Y,2)
        lambda1 = (Sc(i,:).*Sc(i,:))';
        lambda3 = Sc(i,:)';
        lambda4 = lambda3;
        lambda1 = repmat(reshape(lambda1(:),1,1,numel(lambda1(:))),size(A,1),size(A,1));
        lambda3 = repmat(reshape(lambda3(:),1,1,numel(lambda3(:))),size(A,1),size(A,1));
        lambda4 = repmat(reshape(lambda4(:),1,1,numel(lambda4(:))),size(A,1),size(A,1));
        AA = repmat(ScE(i,:),size(Y,1),1).*A;
        R3=repmat(AA,1,n2);
        R3J3 = R3-J3;
        deriv3tmp3(:,i) = sum(R3J3Alpha1.*lambda1 + R3J3Alpha2 - ...
            R3J3Alpha3.*lambda3 - R3J3Alpha4.*lambda4,3)*Y(:,i) + ...
            4*sum(R3J3.*alpha3.*repmat(LoER3(i,:),size(A,1),1),2);
    end
    
    R2=repmat(B,1,n2);
    Z2=repmat(B,n2,1);
    J2=reshape(Z2,size(B,1),[]);
    alphatmp2=reshape(disty,1,[]);
    alpha2=repmat(alphatmp2,size(B,1),1);
    deriv2tmp2=2*((R2-J2).*alpha2*(R2-J2)')*Y;
    
    if lambdaTip ~= 0
        LL = -epsilon*pdinv(distx+n1*epsilon*eye(n1))*L_y*pdinv(distx+n1*epsilon*eye(n1));
        distx4 = distx.*LL;
        R4J4Alpha1 = zeros(size(A,1),size(A,1),C^2);
        R4J4Alpha2 = zeros(size(A,1),size(A,1),C^2);
        R4J4Alpha3 = zeros(size(A,1),size(A,1),C^2);
        R4J4Alpha4 = zeros(size(A,1),size(A,1),C^2);
        ind = 1;
        for c2 = 1:C
            for c1 = 1:C
                Ac1 = A(:,sum(cnt(1:c1-1))+1:sum(cnt(1:c1)));
                Ac2 = A(:,sum(cnt(1:c2-1))+1:sum(cnt(1:c2)));
                R4 = repmat(Ac1,1,size(Ac2,2));
                Z4 = repmat(Ac2,size(Ac1,2),1);
                J4 = reshape(Z4,size(A,1),[]);
                alphatmp4=reshape(distx4(sum(cnt(1:c1-1))+1:sum(cnt(1:c1)), ...
                    sum(cnt(1:c2-1))+1:sum(cnt(1:c2))),1,[]);
                alpha4=repmat(alphatmp4,size(A,1),1);
                R4J4Alpha1(:,:,ind) = 2*R4.*alpha4*R4';
                R4J4Alpha2(:,:,ind) = 2*J4.*alpha4*J4';
                R4J4Alpha3(:,:,ind) = 2*R4.*alpha4*J4';
                R4J4Alpha4(:,:,ind) = 2*J4.*alpha4*R4';
                ind = ind + 1;
            end
        end
        
        alphatmp4=reshape(distx4,1,[]);
        alpha4=repmat(alphatmp4,size(A,1),1);
        derivReg1 = zeros(size(Y));
        for i = 1:size(Y,2)
            lambda1 = repmat((Sc(i,:).*Sc(i,:))',[1 C]);
            lambda2 = repmat(Sc(i,:).*Sc(i,:),[C 1]);
            lambda3 = Sc(i,:)'*Sc(i,:);
            lambda4 = lambda3;
            lambda1 = repmat(reshape(lambda1(:),1,1,numel(lambda1(:))),size(A,1),size(A,1));
            lambda2 = repmat(reshape(lambda2(:),1,1,numel(lambda2(:))),size(A,1),size(A,1));
            lambda3 = repmat(reshape(lambda3(:),1,1,numel(lambda3(:))),size(A,1),size(A,1));
            lambda4 = repmat(reshape(lambda4(:),1,1,numel(lambda4(:))),size(A,1),size(A,1));
            AA = repmat(ScE(i,:),size(Y,1),1).*A;
            R4=repmat(AA,1,n1);
            Z4=repmat(AA,n1,1);
            J4=reshape(Z4,size(AA,1),[]);
            R4J4 = R4-J4;
            derivReg1(:,i) = -sum(R4J4Alpha1.*lambda1 + R4J4Alpha2.*lambda2 - ...
                R4J4Alpha3.*lambda3 - R4J4Alpha4.*lambda4,3)*Y(:,i) - ...
                2*sum(R4J4.*alpha4.*repmat(LoERZ(i,:),size(A,1),1),2);
        end
    else
        derivReg1 = 0;
    end
end
% c=mat2cell(Asvm,size(A,1),cntsemi);
reg=zeros(size(Y));
% for i = 1 : size(c,2)
%     mu=repmat(mean(c{i},2),1,size(c{i},2));
%     reg = reg+ 2*(c{i}-mu)*(c{i}-mu)'*Y;
% end
df=lambdaMMD*(deriv3tmp3-deriv1tmp1-deriv2tmp2)./sigma+ru*reg+lambdaTip*derivReg1./sigma;