function parametersLS(A,B,W,Sc,Lo,ScE,LoE,sigma,ru,cnt,Asvm,cntsemi, beta, L, lambdaMMD, lambdaTip, lambdaLS,epsilon)
% PARAMETERS	initializes the parameters for an instance of a 
%		minimization problem. add ls transform
%
%	PARAMETERS(A)
%	A is expected to be a square matrix
%
% role	sets up the global parameters used at all levels of computation.

	global FParameters;
	FParameters = [];
	FParameters.A = A;
    FParameters.B = B;
    FParameters.Sc = Sc;
    FParameters.Lo = Lo;
    FParameters.ScE = ScE;
    FParameters.LoE = LoE;
    FParameters.W = W;
    FParameters.sigma = sigma;
  	FParameters.ru = ru;
    FParameters.cnt = cnt;
    FParameters.Asvm = Asvm;
    FParameters.cntsemi = cntsemi;
    FParameters.beta = beta;
    FParameters.L = L;
    FParameters.lambdaMMD = lambdaMMD;
    FParameters.lambdaTip = lambdaTip;
    FParameters.lambdaLS = lambdaLS;
    FParameters.epsilon = epsilon;