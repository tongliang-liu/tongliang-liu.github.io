function [W, beta] = cic(XS, YS, XT, YT, pars)
% Extract conditional invariant components via iterative estimating
% target density ratio beta and linear projection matrix W
% Inputs:
%       XS - features on training domain
%       YS - target on training domain
%       XT - features on test domain
%       YT - target on test domain
%       pars - parameters of the algorithm
%           pars.W - initial projection matrix W
%           pars.beta - initial class ratio beta
%           pars.DipIter -  dip iterations (no update of beta)
%           pars.CicIter -  cic iterations (iterate between W and
%           beta)
%           pars.CicIter0 - initial iterations of gradient descent on W
%           pars.CicInnerIter -  inner iterations of gradient descent on W
%           pars.tolcost - tolerance of the cost function
%           pars.sigma - kernel width on X
%           pars.width_L_beta - kernel width on continuous Y for
%           regularization
%           pars.lambda_beta - regularization parameter for L_beta
%           pars.lambdaMMD - regularization parameter for MMD term
%           pars.lambdaTip - regularization parameter for target information preserving term
%           pars.thresDiscrete - threshold to determine whether Y is discrete or
%           continuous
%           pars.epsilon - kernel regularization
%           pars.updateBeta - 0:dip; 1:cic
% Outputs:
%       W - estimated projection matrix
%       beta - estimated target density ratio

%% Initilization
W = pars.W;
beta = pars.beta;
maxDipIter = pars.maxDipIter;
maxCicIter = pars.maxCicIter;
maxCicIter0 = pars.maxCicIter0;
maxCicInnerIter = pars.maxCicInnerIter;
tolcost = pars.tolcost;
sigma = pars.sigma;
width_L_beta = pars.width_L_beta;
lambda_beta = pars.lambda_beta;
lambdaTip = pars.lambdaTip;
lambdaMMD = pars.lambdaMMD;
epsilon = pars.epsilon;
thresDiscrete = pars.thresDiscrete;
updateBeta = pars.updateBeta;

if numel(unique(YS)) <= thresDiscrete
    discrete = 1;
else
    discrete = 0;
end

% calculate kernel on Y
if discrete == 1
    L = double(kron_kernel(YS));
end

parameters(XS',XT',2*sigma^2,0,[],XS',[],beta,L,...
    lambdaTip,lambdaMMD,epsilon); %1/(4*2*sigma^2)
global FParameters;
if updateBeta == 0  % dip
    if maxDipIter~=0
        [W, info] = stiefelW_cic(W, maxDipIter,tolcost);
    end
    return;
end

% main loop
for iter = 1:maxCicIter
    fprintf('iter %d\n', iter); 
    if maxCicInnerIter~=0  
    % solve W
    [W, info] = stiefelW_cic(W, maxCicInnerIter,tolcost);
    end
    % solve beta
    XSct = XS * W;
    XTct = XT * W;
    if updateBeta~=0 && iter>maxCicIter0
        beta = betaKMM_targetshift_simple(XSct, YS, XTct, YT, sigma, width_L_beta, lambda_beta);
        FParameters.beta = beta;
    end
    fprintf('----------------------------\n');
end


function [W, info] = stiefelW_cic(W, maxInnerIter,tolcost)
%% solve W using manopt toolbox

Gr = grassmannfactory(size(W,1), size(W,2));
problem.M = Gr;
problem.cost = @(X)    F(X);
problem.egrad = @(X)   dF(X);
%figure,checkgradient(problem);
options.maxiter = maxInnerIter;
options.tolgradnorm = 0;
options.tolcost = tolcost;
% options.stopfun = @mystopfun;

[W, xcost, info, options] = conjugategradient(problem, W, options);
% figure, semilogy([info.iter],[info.cost]);

function L = kron_kernel(Y)
% kronecker kernel matrix
T = length(Y);
L = (repmat(Y, 1, T) == repmat(Y', T,1));
