function [W, ScE, LoE, beta] = ctc(XS, YS, XT, YT, pars)
% Extract conditional transferrable components via iterative estimating
% target density ratio beta and linear projection matrix W, and
% location-scale (LS) transform (Sc and Lo)
% Inputs:
%       XS - features on training domain
%       YS - target on training domain
%       XT - features on test domain
%       YT - target on test domain
%       pars - parameters of the algorithm
%           pars.W - initial projection matrix W
%           pars.Sc - initial scale matrix Sc
%           pars.Lo - initial location matrix Lo
%           pars.beta - initial class ratio beta
%           pars.maxCtcIter -  ctc iterations (iterate between W, LS, and beta)
%           pars.maxCtcInnerIterW - inner iterations of gradient descent on W
%           pars.maxCtcInnerIterLS - inner iterations of gradient descent on LS
%           pars.maxCtcIter0 - initial iterations of gradient descent on W
%           pars.tolcost - tolerance of the cost function
%           pars.sigma - kernel width on X
%           pars.width_L_beta - kernel width on continuous Y for regularization
%           pars.lambda_beta - regularization parameter for L_beta
%           pars.lambdaMMD - regularization parameter for MMD term
%           pars.lambdaTip - regularization parameter for target information preserving term
%           pars.lambdaLS - regularization parameter for LS transform
%           pars.thresDiscrete - threshold to determine whether Y is discrete or continuous
%           pars.epsilon - kernel regularization
%           pars.updateBeta - 0:no update of beta, 1: update beta
%           pars.updateW - 0: no update of W, 1: update W
%           pars.updateLS - 0: no update of LS, 1: update LS
% Outputs:
%       W - estimated projection matrix
%       ScE - estimated scale matrix
%       LoE - estimated translation matrix
%       beta - estimated target density ratio

%% Initilization
W = pars.W;
Sc = pars.Sc;
Lo = pars.Lo;
beta = pars.beta;
maxCtcIter = pars.maxCtcIter;
maxCtcInnerIterW = pars.maxCtcInnerIterW;
maxCtcInnerIterLS = pars.maxCtcInnerIterLS;
maxCtcIter0 = pars.maxCtcIter0;
tolcost = pars.tolcost;
sigma = pars.sigma;
width_L_beta = pars.width_L_beta;
lambda_beta = pars.lambda_beta;
lambdaMMD = pars.lambdaMMD;
lambdaTip = pars.lambdaTip;
lambdaLS = pars.lambdaLS;
epsilon = pars.epsilon;
thresDiscrete = pars.thresDiscrete;
updateBeta = pars.updateBeta;
updateW = pars.updateW;
updateLS = pars.updateLS;

cnt=[];
for i=1:numel(unique(YS))
    cnt=[cnt sum(YS==i)];
end

if numel(unique(YS)) <= thresDiscrete
    discrete = 1;
else
    discrete = 0;
end

% calculate kernel on Y
if discrete == 1
    L = double(kron_kernel(YS));
end

[ScE, LoE] = matrixLS(Sc, Lo, cnt);
parametersLS(XS',XT',W,Sc,Lo,ScE,LoE,2*sigma^2,0,cnt,XS',...
    cnt,beta,L,lambdaMMD,lambdaTip,lambdaLS,epsilon); %1/(4*2*sigma^2)

global FParameters;
% main loop
for iter = 1:maxCtcIter    
    fprintf('iter %d\n', iter);
    % solve W
    if updateW ~= 0
        W = stiefelW_ctc(W, maxCtcInnerIterW, tolcost); 
        FParameters.W = W;
    end
    % solve Sc and Lo
    if updateLS ~= 0
        [Sc, Lo] = stiefelLS_ctc(Sc, Lo, maxCtcInnerIterLS, tolcost);
        [ScE, LoE] = matrixLS(Sc, Lo, cnt);
        FParameters.Sc = Sc;
        FParameters.Lo = Lo;
        FParameters.ScE = ScE;
        FParameters.LoE = LoE;
    end
    % solve beta
    if updateBeta ~= 0 && iter > maxCtcIter0
        XSct = XS * W .* ScE' + LoE';
        XTct = XT * W;
        beta = betaKMM_targetshift_simple(XSct, YS, XTct, YT, sigma, width_L_beta, lambda_beta);
        FParameters.beta = beta;
    end
    fprintf('----------------------------\n');
end

function [Sc, Lo, info] = stiefelLS_ctc(Sc, Lo, maxInnerIter,tolcost)
%% solve W using manopt toolbox
W = [Sc,Lo];
% Gr = grassmannfactory(size(W,1), size(W,2));
Gr = euclideanfactory(size(W,1), size(W,2));
%  Gr = stiefelfactory(size(W,1), size(W,2));
problem.M = Gr;
problem.cost = @(X)    FLS_LS(X);
problem.egrad = @(X)   dFLS_LS(X);
%figure,checkgradient(problem);
options.maxiter = maxInnerIter;
options.tolgradnorm = 0;
options.minstepsize = 1e-10;
% options.stopfun = @mystopfun;
options.tolcost = tolcost;
[W, xcost, info, options] = conjugategradient(problem, W, options);
Sc = W(:,1:size(W,2)/2);
Lo = W(:,size(W,2)/2+1:end);
% figure, semilogy([info.iter],[info.cost]);

function [W, info] = stiefelW_ctc(W, maxInnerIter,tolcost)
%% solve W using manopt toolbox

Gr = grassmannfactory(size(W,1), size(W,2));
% Gr = euclideanfactory(size(W,1), size(W,2));
%  Gr = stiefelfactory(size(W,1), size(W,2));
problem.M = Gr;
problem.cost = @(X)    FW_LS(X);
problem.egrad = @(X)   dFW_LS(X);
%figure,checkgradient(problem);
options.maxiter = maxInnerIter;
options.tolgradnorm = 0;
% options.stopfun = @mystopfun;
options.minstepsize = 1e-10;
options.tolcost = tolcost;

[W, xcost, info, options] = conjugategradient(problem, W, options);
% [W, xcost, info, options] = steepestdescent(problem, W, options);
% figure, semilogy([info.iter],[info.cost]);

function stopnow = mystopfun(problem, x, info, last)
stopnow = (last >= 3 && info(last-2).cost - info(last).cost < 1e-3*abs(info(last-2).cost));

function L = kron_kernel(Y)
% kronecker kernel matrix
T = length(Y);
L = (repmat(Y, 1, T) == repmat(Y', T,1));
