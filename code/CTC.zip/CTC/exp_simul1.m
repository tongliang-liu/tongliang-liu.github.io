% An example showing the difference between DIP, CIC, and CTC:
% - DIP works if prior distribution of labels does not change, and there exist invariant components.
% - CIC works if there exist conditional invariant components.
% - CTC works if there exist conditional transferable components which can be corrected by LS transform
% The generated data has different prior distribution, different class conditional distribution in the y direction,
% but similar conditional distribution in the x direction, with a slight shift in the negative class.
% The slight shift is added to show the advantage of CTC over CIC in the case perfect conditional invariant components do not exist.

addpath(genpath('Manopt_2.0/'));
addpath(genpath('mmd'));
addpath(genpath('targetshift'));

clear;
rng(4);
numTrials = 1;
%% generate data
% source domain
for trialId = 1:numTrials
    n = 500;
    posrS = 0.5; % positive class ratio on source domain
    posrT = 0.4; % positive class ratio on target domain
    nsPos = round(n*posrS);
    nsNeg = round(n*(1-posrS));
    % class conditional distribution parameters on source domain
    mu1 = [1 3 2 1];
    sigma1 = [1 1 1 1.2];
    xp = random('norm', mu1(1), sigma1(1), nsPos, 1);
    yp = random('norm', mu1(2), sigma1(2), nsPos, 1);
    XSP = [xp, yp];
    xn = random('logn', 0, sigma1(3), nsNeg, 1) + mu1(3);
    yn = random('norm', mu1(4), sigma1(4), nsNeg, 1);
    XSN = [xn, yn];
    figure,plot(xp,yp,'r+');
    hold on; plot(xn,yn,'ko');
    axis([-2 10 -2 7]);
    % target domain
    ntPos = round(n*posrT);
    ntNeg = round(n*(1-posrT));
    % class conditional distribution parameters on target domain
    mu2 = [1 1 2.1 3];
    sigma2 = [1 .2 1 .2];
    xp = random('norm', mu2(1), sigma2(1), ntPos, 1);
    yp = random('norm', mu2(2), sigma2(2), ntPos, 1);
    % yp = -random('logn', 0, sigma2(4), ntPos, 1) + mu2(4);
    
    XTP = [xp, yp];
    xn = random('logn', 0, sigma2(3), ntNeg, 1) + mu2(3);
    yn = -random('logn', 0, sigma2(4), ntNeg, 1) + mu2(4);
    % yn = random('norm', mu1(4), sigma1(4), n, 1);
    XTN = [xn, yn];
    figure,plot(xp,yp,'r.');
    hold on; plot(xn,yn,'k.');
    axis([-2 10 -2 7]);
    
    XS = [XSP;XSN];
    YS = [ones(nsPos,1);2*ones(nsNeg,1)];
    XT = [XTP;XTN];
    YT = [ones(ntPos,1);2*ones(ntNeg,1)];
    %% conditional transferable components
    % set parameters
    D = size(XS,2); d = 1;
    pars.W = [1;0];
    pars.W = pars.W/norm(pars.W);
    pars.Sc = ones(d,numel(unique(YS)));
    pars.Lo = zeros(d,numel(unique(YS)));
    pars.beta = [1*ones(nsPos,1); 1*ones(nsNeg,1)];
    pars.tolcost = 1e-5;
    pars.sigma = median(pdist([XS;XT]))*2^0;
    pars.width_L_beta = 0.1;
    pars.lambda_beta = 0.01;
    pars.lambdaTip  = 0.00;  
    pars.lambdaLS = [0.1 0]; % LS regularization
    pars.lambdaMMD = 1;
    pars.epsilon = 0.01;
    pars.thresDiscrete = 35;
    pars.updateW = 1;
    pars.updateLS = 1;
 
    % cic iteration parameters
    pars.maxDipIter = 10;
    pars.maxCicIter = 10; % cic main iterations
    pars.maxCicIter0 = 0; % cic initial iterations
    pars.maxCicInnerIter = 1; % cic iterations in a main iteration
    
    % ctc iteration parameters
    pars.maxCtcIter = 10;
    pars.maxCtcIter0 = 0;
    pars.maxCtcInnerIterW = 1;
    pars.maxCtcInnerIterLS = 1;
    
    fprintf('=====================dip=====================\n');
    pars.updateBeta = 0;
    [W_dip, beta_dip] = cic(XS, YS, XT, YT, pars);
    XS_dip = XS * W_dip;
    XT_dip = XT * W_dip;
    
    fprintf('=====================cic=====================\n');
    pars.updateBeta = 1;
    [W_cic, beta_cic] = cic(XS, YS, XT, YT, pars);
    XS_cic = XS * W_cic;
    XT_cic = XT * W_cic;
    
    fprintf('=====================ctc=====================\n');
    pars.updateBeta = 1;
    [W_ctc, ScE_ctc, LoC_ctc, beta_ctc] = ctc(XS, YS, XT, YT, pars);
    XS_ctc = XS * W_ctc .* ScE_ctc' + LoC_ctc';
    XT_ctc = XT * W_ctc;

    % 1nn classifier
    mdl = fitcknn(XS, YS, 'NumNeighbors', 1);
    YTnn = predict(mdl,XT);
    errorOrigKnn = 100*sum(YT~=YTnn)/numel(YT);
    mdl = fitcknn(XS_dip, YS, 'NumNeighbors', 1);
    YTnn = predict(mdl,XT_dip);
    errorDipKnn = 100*sum(YT~=YTnn)/numel(YT);
    mdl = fitcknn(XS_cic, YS, 'NumNeighbors', 1);
    YTnn = predict(mdl,XT_cic);
    errorCicKnn = 100*sum(YT~=YTnn)/numel(YT);
    mdl = fitcknn(XS_ctc, YS, 'NumNeighbors', 1);
    YTnn = predict(mdl,XT_ctc);
    errorCtcKnn = 100*sum(YT~=YTnn)/numel(YT);
    
    fprintf('\nknn orig mean error: %2.2f%%\n', errorOrigKnn);
    fprintf('knn dip mean error: %2.2f%%\n', errorDipKnn);
    fprintf('knn cic mean error: %2.2f%%\n', errorCicKnn);
    fprintf('knn ctc mean error: %2.2f%%\n', errorCtcKnn);
end
