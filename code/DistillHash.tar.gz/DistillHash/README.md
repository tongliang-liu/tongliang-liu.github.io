
This is the code for: "DistillHash: Unsupervised Deep Hashing by Distilling Data Pairs" 

To run the code, you should download the dataset and specify the image path and labels in the corresponding txt file.
For example, for training dataset, all image path should be given in img_train.txt:

>\path\to\train_img1.png

>\path\to\train_img2.png 

>...

The corresponding labels should be indicated in label_train.txt:

>0 1 0 1 0 1

>0 1 0 1 1 0

>...

After setting the running environment and dataset information. Your can first run the learning_with_noisy_label.py by

python2 learning_with_noisy_label.py

which will learn an estimation of the conditional probability of the noisy labels given a pair of data.

Then your can distill confident labels by:

python2 distill_confident_label.py

After obtaining the confident labels, the final hash model can be trained by:

python2 learning_with_confident_label.py

If you have any questions, please feel free to contact Erkun Yang (erkunyang@gmail.com)
