import numpy as np
import pdb
from scipy.spatial.distance import pdist, squareform

# 'train_code_and_labels.npy' is the codes obtained from the model training with noisy labels. We use it to obtain the conditional probability.
data0_ = np.load('train_code_and_labels.npy')
data0_ = data0_.item()
data_ = data0_['train_codes_img']
dot_ = np.matmul(data_, np.transpose(data_))/2
exp_ = np.exp(-1 * dot_)
# The probability obtained from noisy labels.
pro_ = 1.0/(1.0+exp_) 

# Neibors are obtained according to the cosine distance of original deep features.
temp_feature = np.load('train_feature_and_label_mir.npy')
temp_feature = temp_feature.item()
feature = temp_feature['train_features']
label = temp_feature['train_labels']
euc_ = pdist(feature, 'cosine')
euc_dis = squareform(euc_)
sorted_index = np.argsort(euc_dis , axis = 1)

pro_max = np.zeros([10000,10000])
pro_min = np.zeros([10000,10000])
batch_num = 1000
nn = 20 # you can tune this parameter to obtain more confident pairs.
min_n = 5
start_n = 2 
for i in range(10000):
    nei_index_i = np.tile(sorted_index[i, 0:nn],(nn,1))
    nei_index_i = nei_index_i.flatten('F')
    nei_index_i = np.tile(nei_index_i, [batch_num,1])
    nei_index_i = np.tile(sorted_index[i, (start_n + 0):(start_n + nn)],(nn,1))
    nei_index_i = nei_index_i.flatten('F')
    nei_index_i2 = np.tile(nei_index_i, [batch_num,1])
    print 'percentage:{}%'.format(i/100.0)
    for j in range(10000/batch_num):
        nei_index_j = np.tile(sorted_index[j*batch_num:(j+1)*batch_num,0:nn], (1, nn))
        nei_index_j2 = np.tile(sorted_index[j*batch_num:(j+1)*batch_num,(start_n + 0):(start_n + nn)], (1, nn))
        pro_valid = pro_[nei_index_j, nei_index_j]
        pro_valid2 = pro_[nei_index_j2, nei_index_j2]
        pro_min[i, j*batch_num:(j+1)*batch_num] = np.amin(1 - pro_valid, axis = 1)
        pro_max[i, j*batch_num:(j+1)*batch_num] = np.amin(pro_valid2, axis = 1)

# Obtain positive and negative labels.
distilled_mask1 = (pro_ > (1+pro_max)/2) 
distilled_mask2 = (pro_ < (1-pro_min)/2) 
mask_ = distilled_mask1*1 + (-1)*distilled_mask2
dict_ = {'pair_label': mask_}
np.save('pair_label_mir.npy', dict_)

#-----------------------------------------------------------------------------------------------
# Show some statistics of the distilled labels.
gd_pos = np.matmul(label, np.transpose(label))>0
gd_neg = np.matmul(label, np.transpose(label))==0
pos_num = np.sum(distilled_mask1)
true_pos = np.sum(np.logical_and(distilled_mask1, gd_pos))
ori_pos = np.sum(np.logical_and(euc_dis<0.5, gd_pos))
pos_rate = true_pos*1.0/pos_num
ori_pos_rate = ori_pos*1.0/(np.sum(euc_dis<0.5))
neg_num = np.sum(distilled_mask2)
true_neg = np.sum(np.logical_and(distilled_mask2, gd_neg))
ori_neg = np.sum(np.logical_and(euc_dis>0.5, gd_neg))
neg_rate = true_neg*1.0/neg_num
ori_neg_rate = ori_neg*1.0/(np.sum(euc_dis>0.5))
whole_rate = (true_pos + true_neg)*1.0/(pos_num + neg_num)
orig_rate = (ori_pos + ori_neg)*1.0/100000000.0
print 'pos_rate:{},ori_pos_rate:{}, neg_rate:{}, ori_neg_rate:{}, whole_rate:{}, orig_rate:{}'.format(pos_rate, ori_pos_rate, neg_rate, ori_neg_rate, whole_rate, orig_rate) 




