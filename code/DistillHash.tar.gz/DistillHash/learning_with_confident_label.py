from my_generator import Vgg19
from scipy.spatial.distance import pdist ,squareform
from scipy.stats import norm
import pdb
import random
import tqdm
import prettytensor as pt
import scipy
import h5py
import scipy.io as sio
import tensorflow as tf
import numpy as np
import os, sys
sys.path.append(os.getcwd())
os.environ["CUDA_VISIBLE_DEVICES"] = sys.argv[1]
import batch_data.image_data as dataset
import sklearn.datasets
import time
import functools
import locale
locale.setlocale(locale.LC_ALL, '')

# pairwise loss function
def loss(z_x_meanx1,z_x_text,ss_ ):
    pair_loss=tf.reduce_mean(tf.multiply(tf.abs(ss_),(tf.square(tf.multiply(1.0/hidden_size,tf.matmul(z_x_meanx1, tf.transpose(z_x_text)))- ss_))))
    return pair_loss

# Define the model
def inference(x224):
    with pt.defaults_scope(activation_fn=tf.nn.elu,
                           batch_normalize=True,
                           learned_moments_update_rate=0.0003,
                           variance_epsilon=0.001,
                           scale_after_normalization=True):
        with tf.variable_scope("enc"):
                vgg_net = Vgg19('./vgg16.npy', codelen=hidden_size)
                vgg_net.build(x224, train_model)
                z_x = vgg_net.fc9
                fc7_features = vgg_net.relu7
        return z_x, fc7_features

# Configuration for dataset
config = {
    'img_tr': "dataset/flickr/img_train.txt", 
    'txt_tr': "dataset/flickr/text_train.txt", 
    'lab_tr': "dataset/flickr/label_train.txt",
    'img_te': "dataset/flickr/img_test.txt",
    'txt_te': "dataset/flickr/text_test.txt",
    'lab_te': "dataset/flickr/label_test.txt",
    'img_db': "dataset/flickr/img_database.txt", 
    'txt_db': "dataset/flickr/text_database.txt", 
    'lab_db': "dataset/flickr/label_database.txt",
    'n_train': 10000,
    'n_test': 2000,
    'n_db': 18015,
    'n_label': 24
}
n_train = config['n_train']
n_test = config['n_test']
n_db = config['n_db']
n_label = config['n_label']
train_size = n_train
test_size = n_test
db_size = n_db

# hyper-parameters and placeholder for input
batch_size = 80
hidden_size = int(sys.argv[2])
all_input224 = tf.placeholder(tf.float32, [None, 224 ,224,3])
s_s = tf.placeholder(tf.float32, [batch_size, batch_size])
train_model = tf.placeholder(tf.bool)
pair_loss = pairwise_loss(z_x,z_x, s_s)
params = tf.trainable_variables()
Ei_params = [i for i in params if 'enc' in i.name]
# Learning rate placeholder
lr_E = tf.placeholder(tf.float32, shape=[])

# Optimizer
opt_Ei = tf.train.AdamOptimizer(lr_E, epsilon=1.0).minimize(pair_loss, var_list = Ei_params)           
train_E = opt_Ei
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction = 1.0)
session = tf.Session(config = tf.ConfigProto(gpu_options = gpu_options))

train_data = dataset.import_train(config)
test_data = dataset.import_test(config)
db_data = dataset.import_db(config)
cur_epoch = 0
num_epochs =  20
e_learning_rate = 1e-3
globa_beta_indx = 0
num_examples = n_train
total_batch = int(np.floor(num_examples / batch_size))
epoch = 0     

# Initialize the model
session.run(tf.initialize_all_variables())
pre_epochs =  20
train_batch = int(np.ceil(1.0*n_train/batch_size))

# Load confident labels.
temp_data = np.load('pair_label_mir.npy.npy')
temp_data = temp_data.item()
S = temp_data['pair_label']

# Start training
while epoch < pre_epochs:
    index_range = np.arange(n_train)
    np.random.shuffle(index_range)
    for i in  range(total_batch):
        if (i+1)*batch_size < n_train:
            index = index_range[range(i*batch_size,(i+1)*batch_size)]
        else:
            index = index_range[range(n_train - batch_size, n_train)]
        cur_epoch += 1.0
        e_current_lr = e_learning_rate*1.0
        next_batches224, batch_label = train_data.img_data(index)
        next_batches224 = np.array(next_batches224)
        ss_ = S[index,:][:,index]
        _, PP_err = session.run(
            [
             train_E, pair_loss
             ],
            {
                lr_E: e_current_lr,
                all_input224: next_batches224,
                s_s: ss_,
                train_model: True
            }
            )
        print 'epoch:{}, batch: {},PP_err:{}'.format(epoch,i, PP_err)
    epoch = epoch + 1
