from scipy.spatial.distance import pdist ,squareform
from scipy.stats import norm
import random
import tqdm
import prettytensor as pt
import scipy
import h5py
import scipy.io as sio
import tensorflow as tf
import numpy as np
import os, sys
sys.path.append(os.getcwd())
import batch_data.image_data as dataset
from my_generator import Vgg
import numpy as np
import sklearn.datasets
import time
import functools
import locale
locale.setlocale(locale.LC_ALL, '')

def loss(z_x_meanx1,ss_ ):
    pair_loss=tf.reduce_mean(tf.multiply(tf.abs(ss_),(tf.square(tf.multiply(1.0/hidden_size,tf.matmul(z_x_meanx1, tf.transpose(z_x_meanx1)))- ss_))))
    return pair_loss

def inference(x224):
    with pt.defaults_scope(activation_fn=tf.nn.elu,
                           batch_normalize=True,
                           learned_moments_update_rate=0.0003,
                           variance_epsilon=0.001,
                           scale_after_normalization=True):
        with tf.variable_scope("enc"):
                vgg_net = Vgg('./vgg.npy', codelen=hidden_size)
                vgg_net.build(x224, train_model)
                z_x = vgg_net.fc9
                fc7_features = vgg_net.relu7
        return z_x, fc7_features

batch_size = 24 

# hidden_size is the length of hash codes
hidden_size = 32

# Placeholder for input images
all_input224 = tf.placeholder(tf.float32, [None, 224 ,224,3])
train_model = tf.placeholder(tf.bool)
# Placeholder for pairwise labels
s_s = tf.placeholder(tf.float32, [batch_size, batch_size])

# Define the model
with tf.device('/gpu:0'):
    z_x, fc7_features = inference(all_input224)
    pair_loss = loss(z_x, s_s)
    params = tf.trainable_variables()
    E_params = [i for i in params if 'enc' in i.name]
    lr_E = tf.placeholder(tf.float32, shape=[])
    opt_E = tf.train.AdamOptimizer(lr_E, epsilon=1.0)            
    grads_e = opt_E.compute_gradients(pair_loss, var_list=E_params)

global_step = tf.get_variable(
    'global_step', [],
    initializer=tf.constant_initializer(0), trainable=False)
train_E = opt_E.apply_gradients(grads_e, global_step=global_step)
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction = 1.0)
session = tf.Session(config = tf.ConfigProto(gpu_options = gpu_options))

# indicating training parameters and training dataset
train_size = 5000
test_size = 10000
db_size = 50000
k = 50
config = {
    'img_tr': "dataset/flickr/img_train.txt", 
    'lab_tr': "dataset/flickr/label_train.txt",
    'img_te': "dataset/flickr/img_test.txt",
    'lab_te': "dataset/flickr/label_test.txt",
    'img_db': "dataset/flickr/img_database.txt",  
    'lab_db': "dataset/flickr/label_database.txt",
    'n_train': 10000,
    'n_test': 2000,
    'n_db': 18015,
    'n_label': 24
}
n_train = config['n_train']
n_test = config['n_test']
n_db = config['n_db']
n_label = config['n_label']
train_size = n_train
test_size = n_test
db_size = n_db

train_data = dataset.import_train(config)
train_labels = np.zeros([n_train, n_label])
train_features = np.zeros([ n_train, 4096])
test_data = dataset.import_test(config)
test_labels = np.zeros([n_test, n_label])
db_data = dataset.import_db(config)
db_labels = np.zeros([n_db, n_label])

num_epochs =  50 # The total epoches should be tuned to avoide overfitting.
e_learning_rate = 1e-3
globa_beta_indx = 0
num_examples = n_train
total_batch = int(np.floor(num_examples / batch_size))
epoch = 0     


temp_data = np.load('noisy_label.npy')
#temp_data = np.load('pair_label_mir_1.npy')
temp_data = temp_data.item()
S = temp_data['S']
S = (S>0)*2.0 - 1.0

# Start training/
while epoch < num_epochs:
    iter_ = data_iterator()
    index_range = np.arange(n_train)
    np.random.shuffle(index_range)
    for i in  range(total_batch):
        if (i+1)*batch_size < n_train:
            index = index_range[range(i*batch_size,(i+1)*batch_size)]
        else:
            index = index_range[range(n_train - batch_size, n_train)]
        e_current_lr = e_learning_rate*1.0
        next_batches224,batch_label = train_data.img_data(index)
        next_batches224 = np.array(next_batches224)
        ss_ = S[index,:][:,index]
        _, PP_err= session.run(
            [
             train_E, pair_loss
             ],
            {
                lr_E: e_current_lr,
                all_input224: next_batches224,
                s_s: ss_,
                train_model: True
            }
            )
        print 'epoch:{}, batch: {},PP_err:{}'.format(epoch,i, PP_err)
    epoch = epoch + 1

    # Test for every  epoch.
    if (epoch+1) % 1 ==0 :
        test_codes = np.zeros([n_test,hidden_size])
        test_labels = np.zeros([n_test,n_label])
        dataset_codes = np.zeros([n_db,hidden_size])
        dataset_labels = np.zeros([n_db, n_label])
        test_batch = int(np.ceil(1.0*test_size/batch_size))
        dataset_batch =int(np.ceil(1.0*db_size/batch_size))
        #Extract hash codes for test dataset
        for i in range(test_batch):
            if (i+1)*batch_size < n_test:
                index = range(i*batch_size,(i+1)*batch_size)
            else:
                index = range(i*batch_size, n_test)
            next_batches224, batch_label = test_data.img_data(index)
            next_batches224 = np.array(next_batches224)
            test_softcode = session.run(z_x, feed_dict = {all_input224: next_batches224, train_model: False})
            test_codes[index, :] = test_softcode
            test_labels[index,:] = batch_label
        #Extract hash codes for database dataset
        for i in range(dataset_batch):
            if (i+1)*batch_size < n_db:
                index = range(i*batch_size,(i+1)*batch_size)
            else:
                index = range(i*batch_size, n_db)
            next_batches224, batch_label = db_data.img_data(index)
            next_batches224 = np.array(next_batches224)
            dataset_softcode = session.run(z_x, feed_dict = {all_input224: next_batches224, train_model: False})
            dataset_codes[index, :] = dataset_softcode
            dataset_labels[index, :] = batch_label
        # Save hash codes from noisy labels
        dataset_codes = (dataset_codes>0)*1
        test_codes = (test_codes>0)*1
        dataset_L = dataset_labels  
        test_L = test_labels 
        np.save('train_code_and_labels.npy', dict_)
